#!/bin/sh
set -e
cd /opt/CTFd

# Espera o banco de dados ficar disponível
if [ -n "$DATABASE_URL" ]; then
  echo "[entrypoint] Aguardando banco de dados..."
  python ping.py
fi

# Configuração automática (admin, idioma, tema, página inicial, desafios)
python /opt/CTFd/bootstrap/setup_ptbr.py

# Segue o fluxo normal da imagem oficial
exec /opt/CTFd/docker-entrypoint.sh "$@"
