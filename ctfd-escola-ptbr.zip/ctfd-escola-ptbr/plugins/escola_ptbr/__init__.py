"""
Plugin "escola_ptbr"
 - Força o idioma Português do Brasil (pt_BR) para todos os visitantes
   (usuários logados que escolherem outro idioma no perfil são respeitados).
 - Aplica o visual personalizado (imagem de fundo + CSS) no site e no painel admin.
"""
import os

FORCED_LOCALE = os.environ.get("CTFD_FORCE_LOCALE", "pt_BR")


def _install_locale_selector(app):
    app.config["BABEL_DEFAULT_LOCALE"] = FORCED_LOCALE

    def selector():
        try:
            from CTFd.utils.user import authed, get_current_user_attrs

            if authed():
                user = get_current_user_attrs()
                lang = getattr(user, "language", None) if user else None
                if lang:
                    return lang
        except Exception:
            pass
        return FORCED_LOCALE

    babel_cfg = app.extensions.get("babel")
    if babel_cfg is not None and hasattr(babel_cfg, "locale_selector"):
        babel_cfg.locale_selector = selector
    else:
        print("[escola_ptbr] Aviso: nao foi possivel sobrescrever o seletor de idioma.")


def load(app):
    from CTFd.plugins import (
        register_admin_plugin_stylesheet,
        register_plugin_assets_directory,
        register_plugin_stylesheet,
    )

    register_plugin_assets_directory(
        app, base_path="/plugins/escola_ptbr/assets/"
    )
    register_plugin_stylesheet("/plugins/escola_ptbr/assets/escola.css")
    register_admin_plugin_stylesheet("/plugins/escola_ptbr/assets/admin.css")

    try:
        _install_locale_selector(app)
    except Exception as e:  # nunca derrubar o CTFd por causa do idioma
        print(f"[escola_ptbr] Erro ao configurar idioma: {e}")
