# CTFd Escola (pt-BR) – CyberDay

CTFd pronto para apresentação: já sobe **configurado**, em **português do Brasil**, com **visual personalizado** e alguns **desafios de exemplo**.

## Como subir

Pré-requisito: Docker Desktop (Windows) ou Docker + Compose (Linux/Kali).

```bash
cd ctfd-escola-ptbr
docker compose up -d --build
```

Acesse: **http://localhost:8000**
Na rede da escola, use: `http://IP_DA_SUA_MAQUINA:8000`

| Usuário | Senha |
|---|---|
| `admin` | `admin` |

Painel admin: **http://localhost:8000/admin**

## O que já vem pronto

- Assistente de instalação (`/setup`) pulado automaticamente.
- Idioma forçado em **pt_BR** para todos (variável `CTFD_FORCE_LOCALE`).
- Imagem de fundo + estilo "vidro neon" no site e cabeçalho estilizado no admin.
- Página inicial com banner, botões e regras.
- 5 desafios de exemplo (Introdução, Criptografia, Senhas, Web).

## Personalizar

Edite as variáveis em `docker-compose.yml` (`CTF_NAME`, `ADMIN_PASS`, `SAMPLE_CHALLENGES`...).
A configuração automática só roda **na primeira vez**. Para aplicar mudanças, zere tudo:

```bash
docker compose down -v
docker compose up -d --build
```

Trocar imagens: substitua `plugins/escola_ptbr/assets/fundo.jpg` e `banner.jpg` e rode `docker compose up -d --build`.

## Respostas dos desafios de exemplo

| Desafio | Flag |
|---|---|
| Bem-vindo(a)! | `CTF{bem_vindo_ao_cyberday}` |
| Mensagem secreta | `CTF{base64_nao_e_criptografia}` |
| César mandou | `CTF{cifra_de_cesar}` |
| Senha fraca | `CTF{123456}` |
| Olhe com atenção | `CTF{inspecionar_elemento}` |

## Comandos úteis

```bash
docker compose logs -f ctfd     # ver logs (procure "[setup_ptbr] Pronto!")
docker compose down             # parar (mantém os dados)
docker compose down -v          # parar e apagar tudo
```

> ⚠️ Credenciais `admin:admin` são apenas para demonstração local. Não exponha na internet.
