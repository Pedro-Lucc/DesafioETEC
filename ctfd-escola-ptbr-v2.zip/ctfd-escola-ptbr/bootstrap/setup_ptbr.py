"""
Configuração automática do CTFd (substitui o assistente /setup).
Executa apenas na primeira inicialização; nas próximas, não altera nada.
"""
import os
import sys

sys.path.insert(0, "/opt/CTFd")

from CTFd import create_app
from CTFd.cache import cache
from CTFd.models import Challenges, Flags, Hints, Pages, Users, db
from CTFd.utils import get_config, set_config

ENV = os.environ.get

CTF_NAME = ENV("CTF_NAME", "CyberDay - Capture The Flag")
CTF_DESC = ENV("CTF_DESCRIPTION", "Competição de segurança da informação para estudantes")
ADMIN_USER = ENV("ADMIN_USER", "admin")
ADMIN_PASS = ENV("ADMIN_PASS", "admin")
ADMIN_EMAIL = ENV("ADMIN_EMAIL", "admin@ctf.local")
SAMPLE_CHALLENGES = ENV("SAMPLE_CHALLENGES", "true").lower() == "true"

INDEX_HTML = f"""
<div class="escola-hero">
  <img src="/plugins/escola_ptbr/assets/banner.jpg" alt="CyberDay">
</div>
<div class="escola-box text-center">
  <h1 class="escola-titulo display-4">{CTF_NAME}</h1>
  <p class="lead">Bem-vindo(a) ao nosso <b>Capture The Flag</b>! 🚩</p>
  <p>Resolva os desafios, encontre as <b>flags</b> (no formato <code>CTF{{...}}</code>)
  e acumule pontos para subir no placar.</p>
  <p class="mt-4">
    <a class="btn btn-primary btn-lg me-2" href="/register">Criar conta</a>
    <a class="btn btn-outline-light btn-lg me-2" href="/login">Entrar</a>
    <a class="btn btn-outline-info btn-lg" href="/challenges">Ver desafios</a>
  </p>
</div>
<div class="escola-box">
  <h3>📜 Regras</h3>
  <ul>
    <li>Ataque somente os desafios desta plataforma — nunca sistemas reais!</li>
    <li>Não compartilhe as flags com outras equipes.</li>
    <li>Na dúvida, peça ajuda aos instrutores. Divirta-se! 😄</li>
  </ul>
</div>
"""

DESAFIOS = [
    {
        "name": "Bem-vindo(a)!",
        "category": "Introdução",
        "value": 50,
        "description": "Toda flag segue o formato `CTF{...}`.\n\nPara começar, envie a flag: **CTF{bem_vindo_ao_cyberday}**",
        "flag": "CTF{bem_vindo_ao_cyberday}",
        "hint": None,
    },
    {
        "name": "Mensagem secreta",
        "category": "Criptografia",
        "value": 100,
        "description": "Interceptamos esta mensagem codificada em **Base64**:\n\n`Q1RGe2Jhc2U2NF9uYW9fZV9jcmlwdG9ncmFmaWF9`\n\nConsegue decodificar?",
        "flag": "CTF{base64_nao_e_criptografia}",
        "hint": "Pesquise por \"decodificador Base64 online\".",
    },
    {
        "name": "César mandou",
        "category": "Criptografia",
        "value": 150,
        "description": "Júlio César escondia mensagens deslocando as letras do alfabeto em 3 posições.\n\n`FWI{fliud_gh_fhvdu}`",
        "flag": "CTF{cifra_de_cesar}",
        "hint": "Volte cada letra 3 posições: D → A, E → B...",
    },
    {
        "name": "Senha fraca",
        "category": "Senhas",
        "value": 100,
        "description": "Um usuário usou a senha mais comum do mundo (segundo várias pesquisas), composta só por números em sequência, de 1 a 6.\n\nEnvie no formato `CTF{senha}`.",
        "flag": "CTF{123456}",
        "hint": "Um, dois, três...",
    },
    {
        "name": "Olhe com atenção",
        "category": "Web",
        "value": 150,
        "description": "Desenvolvedores às vezes esquecem coisas no código-fonte das páginas...\n\n<!-- CTF{inspecionar_elemento} -->\nInspecione esta descrição!",
        "flag": "CTF{inspecionar_elemento}",
        "hint": "Clique com o botão direito → Inspecionar (ou F12).",
    },
]


def pick_theme(app):
    themes_dir = os.path.join(app.root_path, "themes")
    for t in ("core-beta", "core"):
        if os.path.isdir(os.path.join(themes_dir, t)):
            return t
    return "core"


def main():
    app = create_app()
    with app.app_context():
        if get_config("setup"):
            print("[setup_ptbr] CTFd já configurado. Nada a fazer.")
            return

        trans = os.path.join(app.root_path, "translations", "pt_BR")
        print(f"[setup_ptbr] Tradução pt_BR presente: {os.path.isdir(trans)}")

        set_config("ctf_name", CTF_NAME)
        set_config("ctf_description", CTF_DESC)
        set_config("user_mode", "users")
        set_config("ctf_theme", pick_theme(app))
        set_config("challenge_visibility", "private")
        set_config("registration_visibility", "public")
        set_config("score_visibility", "public")
        set_config("account_visibility", "public")
        set_config("verify_emails", False)
        set_config("paused", False)
        set_config("start", None)
        set_config("end", None)
        set_config("freeze", None)
        set_config("mail_server", None)
        set_config("mail_port", None)
        set_config("mail_tls", None)
        set_config("mail_ssl", None)
        set_config("mail_username", None)
        set_config("mail_password", None)
        set_config("mail_useauth", None)

        admin = Users(
            name=ADMIN_USER,
            email=ADMIN_EMAIL,
            password=ADMIN_PASS,
            type="admin",
            hidden=True,
        )
        if hasattr(admin, "language"):
            admin.language = "pt_BR"
        db.session.add(admin)

        page = Pages(title=None, route="index", content=INDEX_HTML, draft=False)
        if hasattr(page, "format"):
            page.format = "html"
        db.session.add(page)
        db.session.commit()

        if SAMPLE_CHALLENGES:
            for d in DESAFIOS:
                c = Challenges(
                    name=d["name"],
                    category=d["category"],
                    value=d["value"],
                    description=d["description"],
                    state="visible",
                    type="standard",
                )
                db.session.add(c)
                db.session.commit()
                db.session.add(
                    Flags(challenge_id=c.id, type="static", content=d["flag"], data="")
                )
                if d["hint"]:
                    db.session.add(Hints(challenge_id=c.id, content=d["hint"], cost=0))
            db.session.commit()

        set_config("setup", True)
        db.session.commit()
        try:
            cache.clear()
        except Exception:
            pass
        print(f"[setup_ptbr] Pronto! Login: {ADMIN_USER} / {ADMIN_PASS}")


if __name__ == "__main__":
    main()
