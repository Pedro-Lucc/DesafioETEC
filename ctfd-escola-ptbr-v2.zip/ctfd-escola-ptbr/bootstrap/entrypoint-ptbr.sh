#!/bin/sh
cd /opt/CTFd
export PYTHONPATH=/opt/CTFd:$PYTHONPATH

if [ -n "$DATABASE_URL" ]; then
  echo "[entrypoint] Aguardando banco de dados..."
  python ping.py || true
fi

echo "[entrypoint] Rodando configuracao automatica..."
python /opt/CTFd/bootstrap/setup_ptbr.py || echo "[entrypoint] ERRO no setup_ptbr (CTFd vai subir mesmo assim)"

exec /opt/CTFd/docker-entrypoint.sh "$@"
